# LangChain Model Context Protocol (MCP) Adapters

::: langchain_mcp_adapters.client
    options:
      members:
        - MultiServerMCPClient

::: langchain_mcp_adapters.tools
    options:
      members:
        - load_mcp_tools

::: langchain_mcp_adapters.prompts
    options:
      members:
        - load_mcp_prompt

::: langchain_mcp_adapters.resources
    options:
      members:
        - load_mcp_resources