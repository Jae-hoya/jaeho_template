# Channels

::: langgraph.channels.base
    options:
      members:
        - BaseChannel

::: langgraph.channels
    options:
      members:
        - Topic
        - LastValue
        - EphemeralValue
        - BinaryOperatorAggregate
        - AnyValue
