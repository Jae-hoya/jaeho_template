::: langgraph.config
    options:
      members:
        - get_store
        - get_stream_writer