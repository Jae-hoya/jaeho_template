# RemoteGraph

::: langgraph.pregel.remote
    options:
      members:
        - RemoteGraph
