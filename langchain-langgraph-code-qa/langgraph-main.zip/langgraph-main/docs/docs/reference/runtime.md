# Runtime

::: langgraph.runtime.Runtime
    options:
      show_root_heading: true
      show_root_full_path: false
      members:
        - context
        - store
        - stream_writer
        - previous

::: langgraph.runtime
    options:
      members:
        - get_runtime


