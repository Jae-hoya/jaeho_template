::: langgraph.func
    options:
      members:
        - task
        - entrypoint